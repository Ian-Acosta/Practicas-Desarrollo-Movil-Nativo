
package com.example.practica05

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            PantallaPreferencias()
        }
    }
}

@Composable
fun PantallaPreferencias() {

    val context = LocalContext.current

    val preferencias = remember {
        context.getSharedPreferences(
            "PreferenciasUsuario",
            Context.MODE_PRIVATE
        )
    }

    var nombre by remember { mutableStateOf("") }
    var recibirNotificaciones by remember { mutableStateOf(false) }
    var temaOscuro by remember { mutableStateOf(false) }
    var mensaje by remember { mutableStateOf("") }

    // Recuperar las preferencias al abrir la aplicación.
    LaunchedEffect(Unit) {
        nombre = preferencias.getString("nombre", "") ?: ""

        recibirNotificaciones =
            preferencias.getBoolean("notificaciones", false)

        temaOscuro =
            preferencias.getBoolean("temaOscuro", false)
    }

    // Cambiar los colores de toda la interfaz según el tema.
    MaterialTheme(
        colorScheme = if (temaOscuro) {
            darkColorScheme()
        } else {
            lightColorScheme()
        }
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {

                Text(
                    text = "Configuración de usuario",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Personaliza tus preferencias",
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre del usuario") },
                    placeholder = { Text("Escribe tu nombre") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Interruptor para recibir notificaciones.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Recibir notificaciones",
                        modifier = Modifier.weight(1f)
                    )

                    Switch(
                        checked = recibirNotificaciones,
                        onCheckedChange = {
                            recibirNotificaciones = it
                        }
                    )
                }

                // Interruptor para activar el tema oscuro.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Activar tema oscuro",
                        modifier = Modifier.weight(1f)
                    )

                    Switch(
                        checked = temaOscuro,
                        onCheckedChange = {
                            temaOscuro = it
                        }
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Guardar las preferencias.
                Button(
                    onClick = {
                        if (nombre.isBlank()) {
                            mensaje = "Ingresa el nombre del usuario."
                        } else {
                            preferencias.edit()
                                .putString("nombre", nombre.trim())
                                .putBoolean(
                                    "notificaciones",
                                    recibirNotificaciones
                                )
                                .putBoolean("temaOscuro", temaOscuro)
                                .apply()

                            nombre = nombre.trim()
                            mensaje = "Preferencias guardadas correctamente."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Guardar preferencias")
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Recuperar los últimos datos guardados.
                OutlinedButton(
                    onClick = {
                        nombre =
                            preferencias.getString("nombre", "") ?: ""

                        recibirNotificaciones =
                            preferencias.getBoolean("notificaciones", false)

                        temaOscuro =
                            preferencias.getBoolean("temaOscuro", false)

                        mensaje = "Datos guardados recargados."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Recargar datos guardados")
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Eliminar las preferencias y volver a los valores iniciales.
                OutlinedButton(
                    onClick = {
                        preferencias.edit().clear().apply()

                        nombre = ""
                        recibirNotificaciones = false
                        temaOscuro = false

                        mensaje = "Configuración restablecida."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Restablecer configuración",
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = mensaje,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
