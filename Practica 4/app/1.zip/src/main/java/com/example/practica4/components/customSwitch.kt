package com.example.practica4.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CustomSwitch(
    texto: String,
    activado: Boolean,
    onActivadoChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = texto)

        Spacer(modifier = Modifier.width(12.dp))

        Switch(
            checked = activado,
            onCheckedChange = onActivadoChange
        )
    }
}
