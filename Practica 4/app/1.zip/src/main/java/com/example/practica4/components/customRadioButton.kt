package com.example.practica4.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CustomRadioButton(
    opciones: List<String>,
    seleccion: String,
    onSeleccionChange: (String) -> Unit
) {
    Column {
        opciones.forEach { opcion ->
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = seleccion == opcion,
                    onClick = {
                        onSeleccionChange(opcion)
                    }
                )

                Spacer(
                    modifier = Modifier.width(4.dp)
                )

                Text(text = opcion)
            }
        }
    }
}
