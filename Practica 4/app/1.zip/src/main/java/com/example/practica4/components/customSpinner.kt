package com.example.practica4.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun CustomSpinner(
    opciones: List<String>,
    seleccion: String,
    onSeleccionChange: (String) -> Unit
) {
    var expandido by remember {
        mutableStateOf(false)
    }

    Column {
        OutlinedButton(
            onClick = { expandido = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = seleccion)
        }

        DropdownMenu(
            expanded = expandido,
            onDismissRequest = {
                expandido = false
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            opciones.forEach { opcion ->
                DropdownMenuItem(
                    text = {
                        Text(text = opcion)
                    },
                    onClick = {
                        onSeleccionChange(opcion)
                        expandido = false
                    }
                )
            }
        }
    }
}
