package com.example.practica4.components

import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomDatepicker(
    fechaSeleccionada: String,
    onFechaSeleccionada: (String) -> Unit
) {
    var mostrarCalendario by remember {
        mutableStateOf(false)
    }

    TextButton(
        onClick = { mostrarCalendario = true }
    ) {
        Text(
            text = if (fechaSeleccionada.isEmpty()) {
                "Seleccionar fecha"
            } else {
                "Fecha: $fechaSeleccionada"
            }
        )
    }

    if (mostrarCalendario) {
        val estadoFecha = rememberDatePickerState()

        DatePickerDialog(
            onDismissRequest = {
                mostrarCalendario = false
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val milisegundos =
                            estadoFecha.selectedDateMillis

                        if (milisegundos != null) {
                            val formato = SimpleDateFormat(
                                "dd/MM/yyyy",
                                Locale("es", "MX")
                            )

                            formato.timeZone =
                                TimeZone.getTimeZone("UTC")

                            val fecha = formato.format(
                                Date(milisegundos)
                            )

                            onFechaSeleccionada(fecha)
                        }

                        mostrarCalendario = false
                    }
                ) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        mostrarCalendario = false
                    }
                ) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(state = estadoFecha)
        }
    }
}
