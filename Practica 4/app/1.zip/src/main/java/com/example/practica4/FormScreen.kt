package com.example.practica4

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.practica4.components.CustomCheckbox
import com.example.practica4.components.CustomDatepicker
import com.example.practica4.components.CustomRadioButton
import com.example.practica4.components.CustomSpinner
import com.example.practica4.components.CustomSwitch
import com.example.practica4.components.CustomSwitch

@Composable
fun FormScreen() {

    // Opciones del formulario
    val carreras = listOf(
        "Ingeniería en Sistemas",
        "Ingeniería Civil",
        "Contaduría Pública",
        "Administración de Empresas"
    )

    val turnos = listOf(
        "Matutino",
        "Vespertino",
        "Nocturno"
    )

    // Estados de los controles
    var carrera by remember {
        mutableStateOf(carreras[0])
    }

    var turno by remember {
        mutableStateOf(turnos[0])
    }

    var deporte by remember {
        mutableStateOf(false)
    }

    var musica by remember {
        mutableStateOf(false)
    }

    var lectura by remember {
        mutableStateOf(false)
    }

    var inscrito by remember {
        mutableStateOf(true)
    }

    var fecha by remember {
        mutableStateOf("")
    }

    // Resultado del procesamiento
    var mostrarResumen by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Text(
            text = "Práctica 4",
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            text = "Controles avanzados en Android",
            style = MaterialTheme.typography.titleMedium
        )

        HorizontalDivider()

        // Spinner
        Text(
            text = "1. Selecciona tu carrera",
            style = MaterialTheme.typography.titleSmall
        )

        CustomSpinner(
            opciones = carreras,
            seleccion = carrera,
            onSeleccionChange = {
                carrera = it
                mostrarResumen = false
            }
        )

        // RadioButton
        Text(
            text = "2. Selecciona tu turno",
            style = MaterialTheme.typography.titleSmall
        )

        CustomRadioButton(
            opciones = turnos,
            seleccion = turno,
            onSeleccionChange = {
                turno = it
                mostrarResumen = false
            }
        )

        // CheckBox
        Text(
            text = "3. Actividades de interés",
            style = MaterialTheme.typography.titleSmall
        )

        CustomCheckbox(
            texto = "Deportes",
            isChecked = deporte,
            onCheckedChange = {
                deporte = it
                mostrarResumen = false
            }
        )

        CustomCheckbox(
            texto = "Música",
            isChecked = musica,
            onCheckedChange = {
                musica = it
                mostrarResumen = false
            }
        )

        CustomCheckbox(
            texto = "Lectura",
            isChecked = lectura,
            onCheckedChange = {
                lectura = it
                mostrarResumen = false
            }
        )

        // Switch
        Text(
            text = "4. Estado de inscripción",
            style = MaterialTheme.typography.titleSmall
        )

        CustomSwitch(
            texto = if (inscrito) {
                "Inscripción activa"
            } else {
                "Inscripción inactiva"
            },
            activado = inscrito,
            onActivadoChange = {
                inscrito = it
                mostrarResumen = false
            }
        )

        // DatePicker
        Text(
            text = "5. Fecha de registro",
            style = MaterialTheme.typography.titleSmall
        )

        CustomDatepicker(
            fechaSeleccionada = fecha,
            onFechaSeleccionada = {
                fecha = it
                mostrarResumen = false
            }
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Procesar los datos
        Button(
            onClick = {
                mostrarResumen = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Procesar información")
        }

        // Mostrar el resultado
        if (mostrarResumen) {
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Resumen del formulario",
                        style = MaterialTheme.typography.titleLarge
                    )

                    HorizontalDivider()

                    Text("Carrera: $carrera")
                    Text("Turno: $turno")

                    val actividades = mutableListOf<String>()

                    if (deporte) actividades.add("Deportes")
                    if (musica) actividades.add("Música")
                    if (lectura) actividades.add("Lectura")

                    Text(
                        text = "Actividades: ${
                            actividades.joinToString(", ")
                                .ifEmpty { "Ninguna" }
                        }"
                    )

                    Text(
                        text = "Inscripción: ${
                            if (inscrito) "Activa" else "Inactiva"
                        }"
                    )

                    Text(
                        text = "Fecha: ${
                            fecha.ifEmpty { "No seleccionada" }
                        }"
                    )
                }
            }
        }
    }
}
