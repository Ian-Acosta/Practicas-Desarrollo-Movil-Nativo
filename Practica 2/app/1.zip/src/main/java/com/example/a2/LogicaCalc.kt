package com.example.a2

// Contiene las operaciones matemáticas de la calculadora.
object LogicaCalc {

    // Realiza la operación aritmética indicada.
    fun calcular(
        numero1: Double,
        numero2: Double,
        operacion: String
    ): Double {

        return when (operacion) {
            "+" -> numero1 + numero2
            "-" -> numero1 - numero2
            "*" -> numero1 * numero2

            // Evita dividir entre cero.
            "/" -> {
                if (numero2 == 0.0) {
                    throw ArithmeticException(
                        "No se puede dividir entre cero"
                    )
                }

                numero1 / numero2
            }

            // Informa si se recibe una operación desconocida.
            else -> throw IllegalArgumentException(
                "Operación no válida"
            )
        }
    }

    // Calcula el porcentaje de un número.
    fun calcularPorcentaje(numero: Double): Double {
        return numero / 100.0
    }
}
