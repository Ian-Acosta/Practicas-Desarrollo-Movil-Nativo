package com.example.a2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal

// Colores utilizados en la calculadora.
private val AppBackground = Color(0xFF17212B)
private val CalculatorGreen = Color(0xFF27864A)
private val ButtonGreen = Color(0xFFB9F6CA)
private val DarkScreen = Color(0xFF10251A)
private val OperatorGreen = Color(0xFF75D69A)
private val WhiteText = Color(0xFFFFFFFF)

// Pantalla principal de la calculadora.
@Composable
fun PantallaCalc() {

    // Número que se muestra en la pantalla.
    var pantalla by remember { mutableStateOf("0") }

    var operacionTexto by remember { mutableStateOf("") }

    // Primer número de la operación.
    var primerNumero by remember { mutableStateOf<Double?>(null) }

    // Operador seleccionado.
    var operador by remember { mutableStateOf<String?>(null) }

    // Indica si el siguiente dígito inicia otro número.
    var nuevoNumero by remember { mutableStateOf(true) }

    // Indica si ya se mostró un resultado.
    var resultadoMostrado by remember { mutableStateOf(false) }

    // Restablece el estado de la calculadora.
    fun limpiar() {
        pantalla = "0"
        primerNumero = null
        operador = null
        nuevoNumero = true
        resultadoMostrado = false
    }

    // Muestra un mensaje de error sin cerrar la aplicación.
    fun mostrarError(mensaje: String) {
        pantalla = mensaje
        primerNumero = null
        operador = null
        nuevoNumero = true
        resultadoMostrado = false
    }

    // Agrega un número o el punto decimal.
    fun ingresar(valor: String) {

        // Después de un error, permite comenzar de nuevo.
        if (pantalla == "Error" ||
            pantalla == "División entre cero"
        ) {
            pantalla = "0"
            nuevoNumero = true
        }

        // Después de un resultado, un dígito inicia otra operación.
        if (resultadoMostrado) {
            pantalla = "0"
            nuevoNumero = true
            resultadoMostrado = false
            primerNumero = null
            operador = null
        }

        if (valor == ".") {
            if (nuevoNumero) {
                pantalla = "0."
                nuevoNumero = false
            } else if (!pantalla.contains(".")) {
                pantalla += "."
            }
            return
        }

        // Evita agregar ceros innecesarios al inicio.
        if (nuevoNumero || pantalla == "0") {
            pantalla = valor
            nuevoNumero = false
            operacionTexto = if (operador != null) {
                "${formatoNumero(primerNumero!!)} $operador $pantalla"
            } else {
                pantalla
            }
        } else if (pantalla.length < 15) {
            pantalla += valor
            operacionTexto = if (operador != null) {
                "${formatoNumero(primerNumero!!)} $operador $pantalla"
            } else {
                pantalla
            }
        }
    }

    // Guarda la operación seleccionada.
    fun seleccionarOperacion(nuevaOperacion: String) {

        // No permite utilizar un mensaje de error como número.
        if (pantalla == "Error" ||
            pantalla == "División entre cero"
        ) {
            return
        }

        val numeroActual = pantalla.toDoubleOrNull()

        // Si falta un número, no se realiza ningún cálculo.
        if (numeroActual == null) {
            return
        }

        // Permite realizar operaciones consecutivas.
        if (operador != null &&
            primerNumero != null &&
            !nuevoNumero
        ) {
            try {
                val resultado = LogicaCalc.calcular(
                    primerNumero!!,
                    numeroActual,
                    operador!!
                )

                pantalla = formatoNumero(resultado)
                primerNumero = resultado
            } catch (e: ArithmeticException) {
                mostrarError("División entre cero")
                return
            } catch (e: IllegalArgumentException) {
                mostrarError("Error")
                return
            }
        } else {
            primerNumero = numeroActual
        }

        operador = nuevaOperacion
        nuevoNumero = true
        resultadoMostrado = false
        operacionTexto = "${formatoNumero(primerNumero!!)} $nuevaOperacion"

    }

    // Ejecuta la operación pendiente.
    fun calcularResultado() {

        val numero1 = primerNumero
        val numero2 = pantalla.toDoubleOrNull()
        val operacion = operador

        // Evita calcular con valores vacíos.
        if (numero1 == null ||
            numero2 == null ||
            operacion == null
        ) {
            return
        }

        try {
            val resultado = LogicaCalc.calcular(
                numero1,
                numero2,
                operacion
            )

            operacionTexto =
                "${formatoNumero(numero1)} $operacion ${formatoNumero(numero2)} ="

            pantalla = formatoNumero(resultado)
            primerNumero = null
            operador = null
            nuevoNumero = true
            resultadoMostrado = true

        } catch (e: ArithmeticException) {
            mostrarError("División entre cero")
        } catch (e: IllegalArgumentException) {
            mostrarError("Error")
        }
    }

    // Borra el último dígito ingresado.
    fun borrarUltimo() {
        if (pantalla == "Error" ||
            pantalla == "División entre cero"
        ) {
            limpiar()
            return
        }

        if (resultadoMostrado) {
            limpiar()
            return
        }

        if (nuevoNumero) {
            return
        }

        pantalla = if (pantalla.length <= 1 ||
            (pantalla.length == 2 && pantalla.startsWith("-"))
        ) {
            "0"
        } else {
            pantalla.dropLast(1)
        }

        if (pantalla == "-") {
            pantalla = "0"
        }
    }

    // Fondo y carcasa de la calculadora.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .background(
                    CalculatorGreen,
                    RoundedCornerShape(28.dp)
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // Pantalla donde aparecen las entradas y resultados.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(112.dp)
                    .background(
                        DarkScreen,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(12.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = operacionTexto,
                        color = Color.LightGray,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = pantalla,
                        color = WhiteText,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Primera fila: limpieza y operadores.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcBtn(
                    texto = "C",
                    modifier = Modifier.weight(2f),
                    color = Color(0xFFFFD180),
                    alPresionar = { limpiar() }
                )
                CalcBtn(
                    texto = "/",
                    modifier = Modifier.weight(1f),
                    color = OperatorGreen,
                    alPresionar = { seleccionarOperacion("/") }
                )
                CalcBtn(
                    texto = "*",
                    modifier = Modifier.weight(1f),
                    color = OperatorGreen,
                    alPresionar = { seleccionarOperacion("*") }
                )
            }

            // Segunda fila: 7, 8, 9 y resta.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcBtn("7", Modifier.weight(1f)) { ingresar("7") }
                CalcBtn("8", Modifier.weight(1f)) { ingresar("8") }
                CalcBtn("9", Modifier.weight(1f)) { ingresar("9") }
                CalcBtn(
                    "-",
                    Modifier.weight(1f),
                    OperatorGreen
                ) { seleccionarOperacion("-") }
            }

            // Tercera fila: 4, 5, 6 y suma.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcBtn("4", Modifier.weight(1f)) { ingresar("4") }
                CalcBtn("5", Modifier.weight(1f)) { ingresar("5") }
                CalcBtn("6", Modifier.weight(1f)) { ingresar("6") }
                CalcBtn(
                    "+",
                    Modifier.weight(1f),
                    OperatorGreen
                ) { seleccionarOperacion("+") }
            }

            // Cuarta fila: 1, 2, 3 e igual.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcBtn("1", Modifier.weight(1f)) { ingresar("1") }
                CalcBtn("2", Modifier.weight(1f)) { ingresar("2") }
                CalcBtn("3", Modifier.weight(1f)) { ingresar("3") }
                CalcBtn(
                    "=",
                    Modifier.weight(1f),
                    Color(0xFF8CDEFF)
                ) { calcularResultado() }
            }

            // Quinta fila: cero ancho, decimal y borrar.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcBtn(
                    "0",
                    Modifier.weight(2f)
                ) { ingresar("0") }

                CalcBtn(
                    ".",
                    Modifier.weight(1f)
                ) { ingresar(".") }

                CalcBtn(
                    "⌫",
                    Modifier.weight(1f),
                    Color(0xFFFFAB91)
                ) { borrarUltimo() }
            }
        }
    }
}


// Componente reutilizable para todos los botones.
@Composable
fun CalcBtn(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = ButtonGreen,
    alPresionar: () -> Unit
) {
    Box(
        modifier = modifier
            .height(58.dp)
            .background(color, RoundedCornerShape(14.dp))
            .clickable { alPresionar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = texto,
            color = Color(0xFF153322),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// Convierte el resultado a texto sin decimales innecesarios.
private fun formatoNumero(numero: Double): String {
    if (!numero.isFinite()) {
        return "Error"
    }

    return BigDecimal.valueOf(numero)
        .stripTrailingZeros()
        .toPlainString()
}


/*
// Componente reutilizable para todos los botones.
@Composable
fun CalcBtn(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = ButtonGreen,
    alPresionar: () -> Unit
) {
    androidx.compose.foundation.clickable

    Box(
        modifier = modifier
            .height(58.dp)
            .background(color, RoundedCornerShape(14.dp))
            .androidxComposeClickable(alPresionar),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = texto,
            color = Color(0xFF153322),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// Convierte el resultado a texto sin decimales innecesarios.
private fun formatoNumero(numero: Double): String {
    if (!numero.isFinite()) {
        return "Error"
    }

    return BigDecimal.valueOf(numero)
        .stripTrailingZeros()
        .toPlainString()
}

// Extensión auxiliar para registrar el clic del botón.
private fun Modifier.androidxComposeClickable(
    accion: () -> Unit
): Modifier {
    return this.then(
        Modifier.clickableCompat(accion)
    )
}

// Aplica el modificador clickable de Compose.
private fun Modifier.clickableCompat(
    accion: () -> Unit
): Modifier {
    return androidx.compose.foundation.clickable(
        onClick = accion
    )
}

*/