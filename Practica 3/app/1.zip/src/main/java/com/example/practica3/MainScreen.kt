
package com.example.practica3

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen() {

    val context = LocalContext.current

    // Variables que guardan los datos escritos por el usuario.
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6FA))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        // Título de la pantalla.
        BasicText(
            text = "Mi perfil",
            style = TextStyle(
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF203864)
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        BasicText(
            text = "Ingresa tus datos para continuar",
            style = TextStyle(
                fontSize = 15.sp,
                color = Color.DarkGray
            )
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Campo para capturar el nombre.
        BasicText(
            text = "Nombre completo",
            modifier = Modifier.fillMaxWidth(),
            style = TextStyle(
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                color = Color.Black
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        CampoTexto(
            valor = nombre,
            alCambiar = { nombre = it },
            pista = "Escribe tu nombre"
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Campo para capturar el correo electrónico.
        BasicText(
            text = "Correo electrónico",
            modifier = Modifier.fillMaxWidth(),
            style = TextStyle(
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                color = Color.Black
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        CampoTexto(
            valor = correo,
            alCambiar = { correo = it },
            pista = "ejemplo@correo.com",
            tipo = KeyboardType.Email
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Intent explícito: abre ProfileActivity y envía los datos.
        BotonSimple(
            texto = "Ver perfil",
            color = Color(0xFF2457A7)
        ) {
            if (nombre.isNotBlank() && correo.isNotBlank()) {

                val intent = Intent(
                    context,
                    ProfileActivity::class.java
                )

                // Adjunta los datos al Intent.
                intent.putExtra("nombre", nombre.trim())
                intent.putExtra("correo", correo.trim())

                context.startActivity(intent)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Intent implícito: permite compartir datos con otras aplicaciones.
        BotonSimple(
            texto = "Compartir datos",
            color = Color(0xFF24835B)
        ) {
            if (nombre.isNotBlank() && correo.isNotBlank()) {

                val mensaje = "Mis datos:\n" +
                        "Nombre: ${nombre.trim()}\n" +
                        "Correo: ${correo.trim()}"

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, mensaje)
                }

                context.startActivity(
                    Intent.createChooser(
                        intent,
                        "Compartir mis datos"
                    )
                )
            }
        }
    }
}

// Campo de texto reutilizable, sin componentes Material.
@Composable
fun CampoTexto(
    valor: String,
    alCambiar: (String) -> Unit,
    pista: String,
    tipo: KeyboardType = KeyboardType.Text
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Color.White,
                RoundedCornerShape(10.dp)
            )
            .border(
                1.dp,
                Color(0xFFB9C3D0),
                RoundedCornerShape(10.dp)
            )
            .padding(14.dp)
    ) {

        // Muestra una indicación cuando el campo está vacío.
        if (valor.isEmpty()) {
            BasicText(
                text = pista,
                style = TextStyle(
                    color = Color.Gray,
                    fontSize = 15.sp
                )
            )
        }

        // Permite escribir y modificar el contenido.
        BasicTextField(
            value = valor,
            onValueChange = alCambiar,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = tipo
            ),
            textStyle = TextStyle(
                color = Color.Black,
                fontSize = 16.sp
            )
        )
    }
}

// Botón sencillo construido con Compose Foundation.
@Composable
fun BotonSimple(
    texto: String,
    color: Color,
    alPulsar: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(
                color,
                RoundedCornerShape(10.dp)
            )
            .clickable {
                alPulsar()
            },
        contentAlignment = Alignment.Center
    ) {
        BasicText(
            text = texto,
            style = TextStyle(
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
