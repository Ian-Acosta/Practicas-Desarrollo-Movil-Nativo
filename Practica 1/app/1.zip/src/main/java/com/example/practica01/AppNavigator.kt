package com.example.practica01

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun AppNavigator() {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "first"
    ) {

        composable(
            route = "first"
        ) {
            FirstScreen(
                onNavigate = { texto ->

                    val textoCodificado = Uri.encode(texto)

                    navController.navigate(
                        "second/$textoCodificado"
                    )
                }
            )
        }

        composable(
            route = "second/{texto}",
            arguments = listOf(
                navArgument("texto") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->

            val texto = backStackEntry.arguments
                ?.getString("texto") ?: ""

            SecondScreen(
                texto = texto,
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}